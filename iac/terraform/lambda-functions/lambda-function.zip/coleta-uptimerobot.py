import pymysql
import json
import requests
import socket
from typing import Dict, List, Tuple, Optional

def lambda_handler(event, context):
    import sys

    API_KEY = "u442462-aeca5d9d04b8c09b00d453fc"  # Substitua pela sua chave de API

    url = "https://api.uptimerobot.com/v2/getMonitors"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Cache-Control": "no-cache"
    }
    data = {
        "api_key": API_KEY,
        "format": "json",
        "custom_uptime_ratios": "1"
    }

    response = requests.post(url, headers=headers, data=data)

    def to_int(value):
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    if response.status_code == 200:
        result = response.json()
        print('API result:', json.dumps(result, indent=2))  # Debug: mostra o resultado da API
        monitors = result.get("monitors", [])
        print('Monitors:', json.dumps(monitors, indent=2))  # Debug: mostra os monitores

        # Conexão com o banco MySQL
        conn = pymysql.connect(
            host="10.0.101.74",
            user="inventario_infra",
            password="jpLwn31Cu06B792",
            database="inventario_infra"
        )
        cursor = conn.cursor()

        for monitor in monitors:
#            print('Monitor custom_uptime_ratio:', monitor.get('custom_uptime_ratio'))  # Debug: mostra o valor antes de inserir
            cursor.execute("""
                INSERT INTO uptimerobot_monitors (
                    monitor_id, friendly_name, url, status, type, subtype,
                    keyword_type, keyword_value, http_username, http_password,
                    port, `interval`, last_check_time, last_response_time, uptime_24h
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    friendly_name=VALUES(friendly_name),
                    url=VALUES(url),
                    status=VALUES(status),
                    type=VALUES(type),
                    subtype=VALUES(subtype),
                    keyword_type=VALUES(keyword_type),
                    keyword_value=VALUES(keyword_value),
                    http_username=VALUES(http_username),
                    http_password=VALUES(http_password),
                    port=VALUES(port),
                    `interval`=VALUES(`interval`),
                    last_check_time=VALUES(last_check_time),
                    last_response_time=VALUES(last_response_time),
                    uptime_24h=VALUES(uptime_24h)
            """,
            (
                monitor.get("id"),
                monitor.get("friendly_name"),
                monitor.get("url"),
                to_int(monitor.get("status")),
                to_int(monitor.get("type")),
                to_int(monitor.get("sub_type")),
                to_int(monitor.get("keyword_type")),
                monitor.get("keyword_value"),
                monitor.get("http_username"),
                monitor.get("http_password"),
                to_int(monitor.get("port")),
                to_int(monitor.get("interval")),
                to_int(monitor.get("last_check_time")),
                to_int(monitor.get("last_response_time")),
                monitor.get("custom_uptime_ratio")
            )
        )
        conn.commit()
        cursor.close()
        conn.close()
        print("Dados inseridos com sucesso!")
    else:
        print(f"Erro: {response.status_code}")
        print(response.text)

if __name__ == "__main__":
    result = lambda_handler({}, {})
    print(json.dumps(result, indent=2))